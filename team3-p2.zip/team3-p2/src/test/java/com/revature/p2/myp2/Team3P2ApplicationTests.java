package com.revature.p2.myp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team3P2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
